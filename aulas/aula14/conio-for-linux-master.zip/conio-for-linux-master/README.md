conio-for-linux
===============

Conio.h for linux 0.4 (beta)

Installation
============

* run `make` to build the library.

Usage
=====

* ncurses must be linked.

Current Status
==============

Currently supported functions:

* gotoxy
* clrscr
* clreol
* kbhit
* textbackground
* textcolor
* delline
* window
* getch
* getche
* cprintf
* cscanf
* cputs
* cgets
* wherex
* wherey

License
=======

This library is licensed under GNU GPLv3 License http://www.gnu.org/copyleft/gpl.html
